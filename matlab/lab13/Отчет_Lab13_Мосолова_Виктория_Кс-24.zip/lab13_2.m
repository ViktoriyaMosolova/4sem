% 2 zadanie
f1 = @(x,y1,y2) y1.*exp(x.^2) + x.*y2;
f2 = @(x,y1,y2) 3.*x-y1+2.*y2;
y1(1)=1;
y2(1)=1;
x(1)=0;
h = 0.1;

% 2 zadanie
xkonechnoe = 3;
N = xkonechnoe/h;
disp('Задание 2');
% m. Eilera
for i=1:N
    y1(i+1)=y1(i) + h*f1(x(i),y1(i),y2(i));
    y2(i+1)=y2(i) + h*f2(x(i),y1(i),y2(i));
    x(i+1) = x(i) + h;
    J = [exp(x(i)^2)   x(i); ...
          -1          2    ];
    stiff_eiler(i) = max(abs(eig(J))) / min(abs(eig(J)));
end
y1_eiler = y1;
y2_eiler = y2;
%disp('Число жесткости m. Eilera');
%stiff_eiler'
disp('y1_eiler');
disp(y1_eiler(end));
disp('y2_eiler');
disp(y2_eiler(end));

% m. Eilera neyavniy
for i=1:N
    y1(i+1)=y1(i) + h*f1(x(i+1),y1(i+1),y2(i+1));
    y2(i+1)=y2(i) + h*f2(x(i+1),y1(i+1),y2(i+1));
    x(i+1) = x(i) + h;
    J = [exp(x(i)^2)   x(i); ...
          -1          2    ];
    stiff_neyavEILER(i) = max(abs(eig(J))) / min(abs(eig(J)));
end
y1_neyavEILER = y1;
y2_neyavEILER = y2;
%disp('Число жесткости m. Eilera neyavniy');
%stiff_neyavEILER'
disp('y1_neyavEILER');
disp(y1_neyavEILER(end));
disp('y2_neyavEILER');
disp(y2_neyavEILER(end));

% График 2
subplot(2,1,2);
plot(x,y1_eiler,'b'); 
hold on; 
plot(x,y2_eiler,'b','Marker','o');
plot(x,y1_neyavEILER,'r'); 
plot(x,y2_neyavEILER,'r','Marker','o'); 
[x_standart2,y_standart2]=ode45(@standart,[1 3], [1 1]); 
disp('y_standart2');
disp(y_standart2(end, :));
plot(x_standart2,y_standart2,'black') 
legend('y1 Эйлер (Явный)','y2 Эйлер (Явный)','y1 Эйлер (Неявный)','y2 Эйлер (Неявный)','Стандартный оператор', 'Location', 'west');
grid on;

function dy=standart(x,y)
    dy=zeros(2,1);
    dy(1)=y(1)*exp(-x^2) + x*y(2);
    dy(2)=3*x-y(1)+2*y(2);
end