clc
clear
% 1 zadanie
f1 = @(x,y1,y2) y1.*exp(-x.^2) + x.*y2;
f2 = @(x,y1,y2) 3.*x-y1+2.*y2;
y1(1)=1;
y2(1)=1;
x(1)=0;
h = 0.1;
xkonechnoe = 1;
N = xkonechnoe/h;

% m. Eilera
disp('Задание 1');
for i=1:N
    y1(i+1)=y1(i) + h*f1(x(i),y1(i),y2(i));
    y2(i+1)=y2(i) + h*f2(x(i),y1(i),y2(i));
    x(i+1) = x(i) + h;
    J = [exp(-x(i)^2)   x(i); ...
          -1          2    ];
    stiff_eiler(i) = max(abs(eig(J))) / min(abs(eig(J)));
end
y1_eiler = y1;
y2_eiler = y2;
%disp('Число жесткости m. Eilera');
%stiff_eiler';
disp('y1_eiler');
disp(y1_eiler(end));
disp('y2_eiler');
disp(y2_eiler(end));


% m. Eilera-Koshi
for i=1:N
    x(i+1) = x(i) + h;
    y1_(i+1)=y1(i) + h*f1(x(i),y1(i),y2(i));
    y2_(i+1)=y2(i) + h*f2(x(i),y1(i),y2(i));
    y1(i+1) = y1(i) + (h/2)*(f1(x(i),y1(i),y2(i)) + f1(x(i+1),y1_(i),y2_(i)));
    y2(i+1) = y2(i) + (h/2)*(f2(x(i),y1(i),y2(i)) + f2(x(i+1),y1_(i),y2_(i)));
    J = [exp(-x(i)^2)   x(i); ...
          -1          2    ];
    stiff_eilkosh(i) = max(abs(eig(J))) / min(abs(eig(J)));
end
y1_eilkosh = y1;
y2_eilkosh = y2;
%disp('Число жесткости m. Eilera Koshi');
%stiff_eilkosh';
disp('y1_eilkosh');
disp(y1_eilkosh(end));
disp('y2_eilkosh');
disp(y2_eilkosh(end));

% m. Runge-Kytta
for i=1:N
    x(i+1) = x(i) + h;
    k1(i) = h*f1(x(i),y1(i),y2(i));
    l1(i) = h*f2(x(i),y1(i),y2(i));
    k2(i) = h*f1(x(i)+h/2,y1(i)+k1(i)/2,y2(i)+l1(i)/2);
    l2(i) = h*f2(x(i)+h/2,y1(i)+k1(i)/2,y2(i)+l1(i)/2);
    k3(i) = h*f1(x(i)+h/2,y1(i)+k2(i)/2,y2(i)+l2(i)/2);
    l3(i) = h*f2(x(i)+h/2,y1(i)+k2(i)/2,y2(i)+l2(i)/2);
    k4(i) = h*f1(x(i+1),y1(i)+k3(i),y2(i)+l3(i));
    l4(i) = h*f2(x(i+1),y1(i)+k3(i),y2(i)+l3(i));
    Dy1(i) = 1/6 * (k1(i) + 2*k2(i) + 2*k3(i) + k4(i));
    Dy2(i) = 1/6 * (l1(i) + 2*l2(i) + 2*l3(i) + l4(i));
    y1(i+1) = y1(i) + Dy1(i);
    y2(i+1) = y2(i) + Dy2(i);
    J = [exp(-x(i)^2)   x(i); ...
          -1          2    ];
    stiff_rungekytta(i) = max(abs(eig(J))) / min(abs(eig(J)));
end
y1_rungekytta = y1;
y2_rungekytta = y2;
%disp('Число жесткости m. Runge-Kytta');
%stiff_rungekytta';
disp('y1_rungekytta');
disp(y1_rungekytta(end));
disp('y2_rungekytta');
disp(y2_rungekytta(end));


% График 1
subplot(2,1,1);
plot(x,y1_eiler,'r'); 
hold on; 
plot(x,y2_eiler,'r','Marker','o');

plot(x,y1_eilkosh,'g'); 
plot(x,y2_eilkosh,'g','Marker','o'); 

plot(x,y1_rungekytta,'b'); 
plot(x,y2_rungekytta,'b','Marker','o'); 

[x_standart,y_standart]=ode45(@standart,[0 1], [1 1]); 
plot(x_standart,y_standart,'m')
disp('y_standart');
disp(y_standart(end, :));
legend('y1 Эйлер','y2 Эйлер','y1 Эйлера-Коши','y2 Эйлера-Коши', 'y1 Рунге-Кутты','y2 Рунге-Кутты','Стандартный оператор', 'Location', 'west');
grid on;


function dy=standart(x,y)
    dy=zeros(2,1);
    dy(1)=y(1)*exp(-x^2) + x*y(2);
    dy(2)=3*x-y(1)+2*y(2);
end