ezplot('tan(x/2)');
axis([-pi pi -10 10])