ezplot('exp(-x^2/2)', [-1.5 1.5]);
hold on
ezplot('x^4-x^2', [-1.5 1.5]);
hold off