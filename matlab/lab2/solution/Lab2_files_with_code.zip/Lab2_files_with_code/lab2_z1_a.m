x=-4:0.1:4;
y=x.^3-x;
plot(x, y)